import React from 'react'

function loading() {
  return (
    <div>loading</div>
  )
}

export default loading