import React from "react";
import Header from "../../components/Header/Header";
import Hero from "../../components/HeroSection/Hero";
import Footer from "../../components/footer/footer";
import OurTeam from "../../components/OurTeam/OurTeam";
import AboutProject from "../../components/About-The-Project/aboutus";
import Contactus from "../../components/Contact-us/Contactus";
function home() {
  return (
    <div>
      <Header />
      <Hero />
      <AboutProject />
      <OurTeam />
      <Contactus />
      <Footer />
    </div>
  );
}

export default home;
