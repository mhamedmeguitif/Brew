import React from 'react'
import "./Profile_1.css"
function Profile_1() {
  return (
    <div className="body_profile">
        <div className="Navigation">
            <ul>
                <li className="list active">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="home-outline"></ion-icon></span>
                        <span className="title_p">Home</span>
                    </a>
                </li>


                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="person-outline"></ion-icon></span>
                        <span className="title_p">Profile</span>
                    </a>
                </li>

                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="chatbubbles-outline"></ion-icon></span>
                        <span className="title_p">Messages</span>
                    </a>
                </li>

                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="settings-outline"></ion-icon></span>
                        <span className="title_p">Settings</span>
                    </a>
                </li>

                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="help-outline"></ion-icon></span>
                        <span className="title_p">Help</span>
                    </a>
                </li>

                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="lock-closed-outline"></ion-icon></span>
                        <span className="title_p">Password</span>
                    </a>
                </li>

                <li className="list">
                    <a href="#">
                        <span className="icon_Profile"><ion-icon name="exit-outline"></ion-icon></span>
                        <span className="title_p">Sign Out </span>
                    </a>
                </li>


            </ul>
        </div>
    </div>
  )
}

export default Profile_1