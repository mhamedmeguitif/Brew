import React, { useState, useContext } from "react";
import axios from "axios";
import { LogedinContext } from "../../Helpers/Context";
import { useHistory } from "react-router";
import "./signin.css";

function Signin() {
  const { logedin, setLogedin } = useContext(LogedinContext);
  const [classItem, setClassItem] = useState("right-panel-active");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const history = useHistory();
  console.log("initial value " + logedin);
  const data = {
    fullName: fullName,
    username: username,
    email: email,
    password: password,
  };
  const data2 = {
    username: username,

    password: password,
  };

  const submit = (e) => {
    e.preventDefault();
    console.log("fullname :" + fullName);
    console.log("username :" + username);
    console.log("password :" + password);
    console.log("email :" + email);
    console.log(data);

    axios
      .post("http://localhost:5000/api/user/signup", data)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
    // clear the input fields
    setEmail("");
    setPassword("");
    setUsername("");
    setFullName("");
  };
  const submit_login = (e) => {
    e.preventDefault();

    console.log("username login :" + username);
    console.log("password  login:" + password);

    console.log("data to send " + data);
    let url = "http://localhost:5000/api/user/signin";

    axios
      .post(url, data2)
      .then((res) => {
        console.log(res);
        setLogedin(true);

        console.log(logedin);
        history.push("/profile");
      })
      .catch((err) => {
        console.log("err message !" + err);
        setLogedin(false);
      });
    // clear the input fields

    setPassword("");
    setUsername("");
  };

  const changeside1 = () => {
    setClassItem(" ");
  };
  const changeside2 = () => {
    setClassItem(" right-panel-active");
  };

  return (
    <div>
      <div className="body33">
        <div className={`container ${classItem} `} id="container">
          <div className="form-container sign-up-container">

            <form>
              <h1>Create Account</h1>
              <span>or use your email for registration</span>
              <div className="separation-div"></div>
              
              <input
                type="text"
                placeholder="FullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
              <input
                type="text"
                placeholder="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <div className="separation-div"></div>
              <button onClick={submit}>Sign Up</button>
            </form>

          </div>
          <div className="form-container sign-in-container">

            <form action="#">
              <h1>Sign in</h1>
              <span>or use your account</span>
              <div className="separation-div"></div>
              
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            
              
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <div className="separation-div"></div>

              <button onClick={submit_login}>Sign In</button>
            </form>

          </div>
          <div className="overlay-container">

            <div className="overlay">
              <div className="overlay-panel overlay-left">
                <h1>Welcome Back!</h1>
                <p>
                  To keep connected with us please login with your personal info
                </p>
                <button className="ghost" onClick={changeside1}>
                  Sign In
                </button>
              </div>
              <div className="overlay-panel overlay-right">
                <h1>Hello, Friend!</h1>
                <p>Enter your personal details and start journey with us</p>
                <button className="ghost" onClick={changeside2}>
                  Sign Up
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signin;
