import React  , {useContext}from 'react'
import UserProfile from '../../components/userProfile/userProfile'
import {LogedinContext} from '../../Helpers/Context'
import useNotification from "../../Hooks/useNotification";
import { Redirect } from "react-router";
function Profile() {
  const { notifdata } = useNotification();
 

return (
  <div>
    <UserProfile/>
  </div>
)
}

export default Profile