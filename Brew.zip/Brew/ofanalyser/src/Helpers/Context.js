import { createContext } from 'react'


export const LogedinContext = createContext({})
export const isLoading = createContext({})