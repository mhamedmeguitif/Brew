import { useState, useEffect } from "react";
import axios from "axios";

function useCreateStream() {
    const [resData, setResData] = useState("");

    var webaddr = ""
    let stream_name = "";
    // req configuration
    const data = {
        input: {
            path: "/opendaylight-inventory:nodes",
            "sal-remote-augment:datastore": "CONFIGURATION",
            "sal-remote-augment:scope": "SUBTREE",
        },
    };
    const url_Create_stream =
        "http://192.168.0.188:8181/restconf/operations/sal-remote:create-data-change-event-subscription";
    const config = { auth: { username: "admin", password: "admin" } };

    //make a post req
    useEffect(() => {
        axios
            .post(url_Create_stream, data, config)
            .then((res) => {
                // console.log(res)
                stream_name = res.data.output["stream-name"];
                //console.log(stream_name)
                const baseUrl = "http://192.168.0.188:8181/restconf/streams/stream/"
                const url_full = baseUrl.concat(stream_name);
                axios.get(url_full, config).then((res1) => {

                    setResData(res1.headers.location)
                    if (resData) {
                        const socket = new WebSocket('ws://192.168.0.188:8185/opendaylight-inventory:nodes/datastore=CONFIGURATION/scope=SUBTREE');
                    }



                }).catch((err1) => {
                    console.log(err1)
                })

            })
            .catch((err) => {
                console.log(err)
            });
    }, []);
    if (resData) {

    }


    return { resData };
}

export default useCreateStream;