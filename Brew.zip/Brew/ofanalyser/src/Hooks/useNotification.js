import axios from "axios";
import { useState } from "react";
import XMLParser from "react-xml-parser";

function useNotification() {
    // get the websocket address from ODL controller
    //const { resData } = useCreateStrem();
    const [notifdata, setNotifdata] = useState({});
    const socket = new WebSocket(
        "ws://192.168.0.188:8185/opendaylight-inventory:nodes/datastore=CONFIGURATION/scope=SUBTREE"
    );
    socket.addEventListener("open", () => {
        console.log("we are connected ");
    });
    socket.addEventListener("message", ({ data }) => {
        //console.log(data);

        // parse XML to json format
        var Notificationdata = new XMLParser().parseFromString(data);
        //setNotifdata(Notificationdata);

        axios
            .post("http://localhost:5000/api/conflict_resolution/", Notificationdata)
            .then((res) => {
                console.log(res);
            })
            .catch((err) => {
                console.error(err);
            });

        //   console.log(Notificationdata);
    });
    socket.addEventListener("close", () => {
        // console.log("close");
        socket.close();
    });

    if (notifdata.name === "notification") {
        //console.log("***** try to send Data to APi*******")

        return { notifdata };
    } else {
        return { notifdata: "no notification" };
    }
}

export default useNotification;