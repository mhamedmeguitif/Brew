import useCreateStream from "./useCreateStream";
import useGet from "./useGet";

function useSubscribeStream() {
    const { stream_name } = useCreateStream();
    const config = { auth: { username: "admin", password: "admin" } };
    var url_full = "";
    var url = "";
    var websocket_address = "";
    // req parameters

    if (stream_name) {
        url = stream_name;
        const baseUrl = "http://192.168.0.188:8181/restconf/streams/stream/";
        url_full = baseUrl.concat(url);
        console.log("this is from parent  stream name :: " + url_full);
    } else {
        console.log("stream name is empty !!!");
    }
    console.log("beefore the use get");
    const { data } = useGet(url_full, config);
    console.log(data);
    if (data) {
        console.log("web socket address :  " + data);
        websocket_address = data;
        //setData_stream(data)
    }

    return { websocket_address };
}

export default useSubscribeStream;