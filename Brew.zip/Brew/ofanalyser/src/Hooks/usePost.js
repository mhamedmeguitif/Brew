import React, { useEffect, useState } from "react";
import axios from "axios";

function usePost(url, data, config) {
    const [resData, setResData] = useState(null);


    useEffect(() => {
        axios
            .post(url, data, config)
            .then((res) => {
                setResData(res.data);
            })
            .catch((err) => {
                console.log("Err From the UsePost Hook : " + err)
            });
    }, []);
    return { resData };
}

export default usePost;