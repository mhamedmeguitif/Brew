import { useState, useEffect } from "react";
import axios from "axios";

function useGet(url, config) {
    const [data, setData] = useState(null);


    useEffect(() => {
        axios
            .get(url, config)
            .then((responce) => {
                if (responce) {
                    setData(responce.headers.location);
                }
            })
            .catch((err) => {
                if (err) {
                    console.log("Err from Use Get " + err)
                }
            });
    }, []);

    return { data };
}

export default useGet;