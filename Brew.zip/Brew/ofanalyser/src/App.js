import React, { useState, useEffect, useMemo } from "react";
import { Route, Switch } from "react-router-dom";
import "./App.css";
import useNotification from "./Hooks/useNotification";
import Profile from "./Pages/Profile_1/Profile_1";
import Signin from "./Pages/Login/signin";
import Home from "./Pages/Home/home";
import axios from "axios";

function App() {
  return (
    <div className="App">
      <Switch>
        <Route path="/" component={Home} exact />{" "}
        <Route path="/login" component={Signin} exact />{" "}
        <Route path="/profile" component={Profile} exact />{" "}
      </Switch>{" "}
    </div>
  );
}

export default App;
