import React from "react";
import "./aboutus.css";
import Paper from "@mui/material/Paper";

function aboutus() {
  return (
    <div id="#home#contact">
     <div className="devider"></div>
    <div className="containerParent">
    
      <div className="about_left">
        <div className="ImageContainer">
        <div className="about_img"></div>
        </div>
        
      </div>
      <div className="about_right ">
     <div className="aboutleft_container"> 
     <Paper elevation={24}
     
     
     className="papaer">
      <div className="About_Title">
          
          <h1 className="titleText">about the Project</h1>
          <div className="line"></div>
        </div>
        <div className="about_desc">
          <p className="aboutdescText">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum,
            eaque cum? Blanditiis perferendis nesciunt sint autem eligendi atque
            at accusamus delectus qui sunt, praesentium quisquam, possimus
            recusandae rem quod cumque!
          </p>
        </div>
      </Paper></div>
        
      </div>
    </div>
    </div>
  );
}

export default aboutus;
