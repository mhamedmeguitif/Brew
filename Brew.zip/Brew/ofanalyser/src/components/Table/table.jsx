import React from "react";
import "./table.css";
function table() {
  return (
    <div className="Details">
      <main class="st_viewport">
        <table>
          <tr className="TableHeader">
            <th className="_Time">Time </th>
            <th className="_Node">Node ID </th>
            <th className="_Table">Table ID </th>
            <th className="_Flow">Flow ID </th>
            <th className="_Priority">Priority</th>
            <th className="_ipv4src">Source_IP</th>
            <th className="_ipv4dst">Dest_IP</th>
            <th className="_Action">Action</th>
            <th className="_State">State</th>
          </tr>
          <tr className =  "TableBody">
            <td>4:23 PMdddddddddddddddddddddddddddddddddddddddddddd </td>
            <td>openflow:1</td>
            <td>0</td>
            <td>Rule 1</td>
            <td>52</td>
            <td>10.5.50.0/24</td>
            <td>10.211.1.63/32</td>
            <td>forward</td>
            <td>Added</td>
          </tr>
          <tr className =  "TableBody">
            <td>4:23 PM </td>
            <td>openflow:1</td>
            <td>0</td>
            <td>Rule 1</td>
            <td>52</td>
            <td>10.5.50.0/24</td>
            <td>10.211.1.63/32</td>
            <td>forward</td>
            <td>Added</td>
          </tr>
          <tr className =  "TableBody">
            <td>4:23 PM </td>
            <td>openflow:1</td>
            <td>0</td>
            <td>Rule 1</td>
            <td>52</td>
            <td>10.5.50.0/24</td>
            <td>10.211.1.63/32</td>
            <td>forward</td>
            <td>Added</td>
          </tr>
          <tr className =  "TableBody">
            <td>4:23 PM </td>
            <td>openflow:1</td>
            <td>0</td>
            <td>Rule 1</td>
            <td>52</td>
            <td>10.5.50.0/24</td>
            <td>10.211.1.63/32</td>
            <td>forward</td>
            <td>Added</td>
          </tr>
        </table>
      </main>
    </div>
  );
}

export default table;
