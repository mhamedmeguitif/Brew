import React from 'react'
import './footer.css'
function footer() {
  return (
    <div>
        <footer className="footer">
            <div className="footerContainer">
                <div className="footer_Row">
                    <div className="footer_col">
                        <h4> company</h4>
                        <ul>
                            <li><a href="/home">about us</a></li>
                            <li><a href="/home"> our services </a></li>
                            <li><a href="/home">privacy policy</a></li>
                            <li><a href="/home">affiliate program</a></li>
                        </ul>
                    </div>
                    <div className="footer_col">
                        <h4>get help</h4>
                        <ul>
                            <li><a href="/home">FAQ</a></li>
                            <li><a href="/home">shipping</a></li>
                            <li><a href="/home">returns</a></li>
                            <li><a href="/home">order status</a></li>
                            <li><a href="/home">payment options</a></li>
                        </ul>
                    </div>
                    <div className="footer_col">
                        <h4>online shop</h4>
                        <ul>
                            <li><a href="/home">watch</a></li>
                            <li><a href="/home">bag</a></li>
                            <li><a href="/home">shoes </a></li>
                            <li><a href="/home">dress</a></li>
                        </ul>
                    </div>
                    <div className="footer_col">
                        <h4>flow us </h4>
                        <div className="social_links_f">
                            <a href="/home"><i class="fa-brands fa-facebook"></i></a> 
                            
                            <a href="/home"><i class="fa-brands fa-instagram"></i></a> 
                            <a href="/home"><i class="fa-brands fa-github"></i></a>
                            <a href="/home"><i class="fa-brands fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </footer>
    </div>
  )
}

export default footer