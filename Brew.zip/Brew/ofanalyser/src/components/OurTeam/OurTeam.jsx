import React from "react";
import Container from "@mui/material/Container";
import "./OurTeam.css";
function OurTeam() {
  return (
    <div className="aboutallcontainer" id="/home#about">
      <div className="devider"></div>
      <Container className="custumContainerAbout">
        <div className="header">
          <h1>Our Team </h1>
        </div>
        <div className="teamContainer">
          <div className="teams">
            <div className="image_avatar1"></div>
            <div className="name">
              {" "}
              <p className="name_text">Mhamed Meguitif</p>
            </div>
            <div className="aboutDesc">
              <p className="aboutdesctext"> Lorem ipsum dolor sit amet.</p>
            </div>
            <div className="aboutabout">
              {" "}
              <p className="aboutabouttext">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni
                libero et voluptate labore cumque atque eos rem, molestiae
                eveniet assumenda quibusdam laboriosam delectus vitae ab culpa
                laudantium repellendus repudiandae. Quidem.
              </p>
            </div>
            <div className="sociallinks">
              <a href="/home">
                <i class="fa-brands fa-facebook-square"></i>
              </a>
              <a href="/home">
                <i class="fa-brands fa-instagram"></i>
              </a>
              <a href="/home">
                <i class="fa-brands fa-twitter"></i>{" "}
              </a>
              <a href="/home">
                <i class="fa-brands fa-github-alt"></i>{" "}
              </a>
            </div>
          </div>
          <div className="teams">
            <div className="image_avatar2"></div>
            <div className="name">
              {" "}
              <p className="name_text">Ramzi Bouzroura</p>
            </div>
            <div className="aboutDesc">
              <p className="aboutdesctext"> Lorem ipsum dolor sit amet.</p>
            </div>
            <div className="aboutabout">
              {" "}
              <p className="aboutabouttext">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni
                libero et voluptate labore cumque atque eos rem, molestiae
                eveniet assumenda quibusdam laboriosam delectus vitae ab culpa
                laudantium repellendus repudiandae. Quidem.
              </p>
            </div>
            <div className="sociallinks">
              <a href="/home">
                <i class="fa-brands fa-facebook-square"></i>
              </a>
              <a href="/home">
                <i class="fa-brands fa-instagram"></i>
              </a>
              <a href="/home">
                <i class="fa-brands fa-twitter"></i>{" "}
              </a>
              <a href="/home">
                <i class="fa-brands fa-github-alt"></i>{" "}
              </a>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}

export default OurTeam;
