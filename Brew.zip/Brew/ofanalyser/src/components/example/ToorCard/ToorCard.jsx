import React from "react";
import Paper from "@mui/material/Paper";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";

function ToorCard() {
  return (
    
      <Container>
          <Grid container spacing={5}>
        <Grid item xs={3}>
          <Paper elevation={3}>ToorCard</Paper>
        </Grid>
        <Grid item xs={3}>
          <Paper elevation={3}>ToorCard</Paper>
        </Grid>

        <Grid item xs={3}>
          <Paper elevation={3}>ToorCard</Paper>
        </Grid>
        <Grid item xs={3}>
          <Paper elevation={3}>ToorCard</Paper>
        </Grid>
        </Grid>
      </Container>
    
  );
}

export default ToorCard;
