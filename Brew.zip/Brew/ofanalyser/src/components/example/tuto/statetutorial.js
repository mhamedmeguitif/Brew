import React from 'react'

const StateTutorial = ()=> {
   let counter =  1; 

  return
  <div> the counter is :  
    {counter}
  </div>
}


export default StateTutorial ; 
