import React, { useState, forwardRef , useImperativeHandle} from "react";

const Button = forwardRef((props, ref) => {
  const [toggel, setToggle] = useState(false);
  useImperativeHandle(ref , ()=>({
     alterToggle () {
        setToggle(!toggel)
    }  
  }))
  return (
    <div>
      <button>
        Button from chiled
      </button>
      {toggel && <span>Toggle</span>}
    </div>
  );
});

export default Button;
