import React from "react";
import "./contactus.css";
function Contactus() {
  return (
    <div id="#contact">
      <div className="contact" >
        <div className="contact_content">
          <h2>Contact us</h2>
          <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. In rerum
            dolore delectus culpa quisquam distinctio unde neque excepturi
            deleniti nihil, ut tenetur quo molestiae consequuntur iusto atque
            odio recusandae debitis.
          </p>
        </div>
        <div className="contact_container">
          <div className="contact_info">
            <div className="contact_box">
              <div className="contact_icon">
                <i class="fa-solid fa-location-dot"></i>
              </div>
              <div className="contact_text">
                <h3>Address </h3>
                <p>Lorem, ipsum dolor.</p>
              </div>
            </div>
            <div className="contact_box">
              <div className="contact_icon">
                <i class="fa-regular fa-envelope"></i>
              </div>
              <div className="contact_text">
                <h3>Email </h3>
                <p>Lorem, ipsum dolor.</p>
              </div>
            </div>
            <div className="contact_box">
              <div className="contact_icon">
                <i class="fa-solid fa-phone"></i>
              </div>
              <div className="contact_text">
                <h3>Phone </h3>
                <p>Lorem, ipsum dolor.</p>
              </div>
            </div>
          </div>
          <div className="contact_form">
          
            <form>
            <h2>Send Message</h2>
              <div className="inputBox">
                <input type="text" name="" required="required" />
                <span>Full Name</span>
              </div>

              <div className="inputBox">
                <input type="text" name="" required="required" />
                <span>Email</span>
              </div>
              <div className="inputBox">
                <textarea required="required"></textarea>{" "}
                <span>Type Your Message ...</span>
              </div>
              <div className="inputBox">
                <input type="submit" value="Send" />
                
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contactus;
