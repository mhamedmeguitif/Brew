import React from "react";
import "./userProfile.css";
import Header from "../Header/Header";
import Table from "../Table/table";
function UserProfile() {
  return (
    <div>
      <Header />
      <div className = "container_user">
      <div className="sidebar open">
        <ul className="nav-list ">
          <li>
            <a href="/home">
              <i class="fa-brands fa-uncharted"></i>

              <span className="links_name">Redundancy</span>
            </a>
            <span className="tooltip">Redundancy</span>
          </li>

          <li>
            <a href="/home">
            <i class="fa-brands fa-connectdevelop"></i>
              <span className="links_name">Shadowing</span>
            </a>
            <span className="tooltip">Shadowing</span>
          </li>

          <li>
            <a href="/home">
            <i class="fa-brands fa-superpowers"></i>

              <span className="links_name">Overlap</span>
            </a>
            <span className="tooltip">Overlap</span>
          </li>

          <li>
            <a href="/home">
            <i class="fa-brands fa-magento"></i>
              <span className="links_name">Generalization</span>
            </a>
            <span className="tooltip">Generalization</span>
          </li>

          <li>
            <a href="/home">
            <i class="fa-brands fa-nfc-symbol"></i>
              <span className="links_name">Correlation</span>
            </a>
            <span className="tooltip">Correlation</span>
          </li>
        </ul>
      </div>
      <div className= "Content">
      <Table />
      </div>
      </div>
      
    </div>
  );
}

export default UserProfile;
