import React from "react";
//import { NavHashLink as Link } from "react-router-hash-link";
import {Link} from 'react-router-dom'
import "./Header.css";

function Header() {

  return (
    <div className="navBar">
      <div className="Logo">
        <Link to="/home"><i class="fa-solid fa-eye"></i></Link>
      
        <div className="Logo-text"> brew</div>
      </div>
      <ul className="Nav-Items">
        <li><a href="#about">About Project</a></li>
        <li><a href="#team">Team</a></li>
        <li><a href="/login">Contact</a></li>
        <li><a href="/login">Conect</a></li>
      </ul>

    </div>
  );
}

export default Header;
