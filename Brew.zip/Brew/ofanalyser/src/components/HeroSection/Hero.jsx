import React from "react";
import Typical from "react-typical";
import "./Hero.css";

function Hero() {
  return (
    <div>
      <div className="Main_Container">
        <div className="Parent_Container ">
          <div className="Right_Side">
            <div className="Title">
              <h1 className="title_h1">
                <Typical
                  loop={Infinity}
                  wrapper="b"
                  steps={[
                    "welcome",
                    1500,
                    "to",
                    1500,
                    "our",
                    1500,
                    "Project",
                    2000,
                  ]}
                />
              </h1>
            </div>
            <div className="SubTitle">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Error
                dolorem eos, quidem suscipit consequuntur cumque consectetur,
                ducimus natus obcaecati iure quae quasi unde voluptate ad a
                consequatur! Vel, quia inventore!{" "}
              </p>
            </div>{" "}
          </div>
          <div className="Left_Side">
            <div className="img_home"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Hero;
