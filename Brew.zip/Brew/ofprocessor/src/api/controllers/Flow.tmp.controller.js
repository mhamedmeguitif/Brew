const db = require("../Models");
const Flow = db.flow;
exports.saveFlow = (req, res) => {
    const flow = new Flow(req.body)
    console.log(req.body.instructions.instruction[0].apply_actions.action)







    flow.save((err, flow) => {
        if (err) {
            res.status(500).send({ message: err });
            return;
        }
        res.send(flow);
    })
}