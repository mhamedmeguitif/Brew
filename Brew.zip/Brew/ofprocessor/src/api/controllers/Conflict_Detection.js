var Netmask = require("netmask").Netmask;
const { Conflict_res } = require("./Conflict_resolution");
const Data_Extraction = (notifdata) => {
    var NodeId = "";
    var tableID = "";
    var Flow = [];
    var FlowTable = [];
    if (notifdata.children[1].children[3].children[1].value == "deleted") {} else {
        for (let i = 0; i < notifdata.children[1].children.length; i++) {
            if (notifdata.children[1].children[i].children[2]) {
                if (
                    notifdata.children[1].children[i].children[2].children[0].name ==
                    "node"
                ) {
                    NodeId =
                        notifdata.children[1].children[i].children[2].children[0]
                        .children[0].value;
                }
            }
        }
        for (let i = 0; i < notifdata.children[1].children.length; i++) {
            if (notifdata.children[1].children[i].children[2]) {
                if (
                    notifdata.children[1].children[i].children[2].children[0].name ==
                    "table"
                ) {
                    var lenght1 =
                        notifdata.children[1].children[i].children[2].children[0].children
                        .length - 1;

                    FlowTable =
                        notifdata.children[1].children[i].children[2].children[0].children;
                }
            }
        }
        for (let i = 0; i < notifdata.children[1].children.length; i++) {
            if (notifdata.children[1].children[i].children[2]) {
                if (
                    notifdata.children[1].children[i].children[2].children[0].name ==
                    "flow"
                ) {
                    Flow =
                        notifdata.children[1].children[i].children[2].children[0].children;
                }
            }
        }
    }
    var Resulted_Data = { NodeId, tableID, Flow, Flow, FlowTable };
    return Resulted_Data;
};

function flow_extraction(flow_entry, data) {
    var tab = {};
    //console.log(data)
    var NodeId = data.NodeId;
    var tableID = "";
    var Flow = [];
    var FlowTable = [];
    var match_tab = {};
    var tmp = flow_entry.find((element) => {
        var action = {};

        tab.node_id = NodeId;

        if (element["name"] == "id") {
            tab.id = element["value"];
        }

        if (element["name"] == "priority") {
            tab.priority = element["value"];
        }

        if (element["name"] == "table_id") {
            tab.table_id = element["value"];
        }

        if (element["name"] == "match") {
            if (element["name"] == "match") {
                if (
                    element["children"].find(
                        (element) => element["name"] == "ipv4-destination"
                    )
                ) {
                    var ipv4_dest = element["children"].find(
                        (element) => element["name"] == "ipv4-destination"
                    )["value"];
                    match_tab.ipv4_dest = ipv4_dest;
                }
            }
            if (element["name"] == "match") {
                if (
                    element["children"].find(
                        (element) => element["name"] == "ipv4-source"
                    )
                ) {
                    var ipv4_source = element["children"].find(
                        (element) => element["name"] == "ipv4-source"
                    )["value"];
                    match_tab.ipv4_source = ipv4_source;
                }
            }
            tab.match_tab = match_tab;
        }

        if (element["name"] == "instructions") {
            for (let i = 1; i < element["children"][0]["children"].length; i++) {
                if (element["children"][0]["children"][i]["name"] == "apply-actions") {
                    for (
                        let j = 0; j < element["children"][0]["children"][i]["children"].length; j++
                    ) {
                        if (
                            element["children"][0]["children"][i]["children"][j][
                                "children"
                            ][1]["name"] == "drop-action"
                        ) {
                            tab.action = { name: "drop-action", value: "" };
                        } else {
                            //actions.push({element["children"][0]["children"][i]["children"][j]["children"][1]["children"][k]["name"]:element["children"][0]["children"][i]["children"][j]["children"][1]["children"][k]["value"]})

                            tab.action = {
                                name: element["children"][0]["children"][i]["children"][j][
                                    "children"
                                ][1]["children"][1]["name"],
                                value: element["children"][0]["children"][i]["children"][j][
                                    "children"
                                ][1]["children"][1]["value"],
                            };
                        }
                    }
                }
            }
        }
    });
    return tab;
}

function flows_exctract(floz, data) {
    flow_honey = [];

    //console.log(ExtractedNotification.FlowTable)
    var tp = floz.find((element) => {
        if (element.name == "flow") {
            //console.log(element.children)
            //console.log("IDS")

            flow_honey.push(flow_extraction(element.children, data));
        }
    });

    return flow_honey;
}

function conflict_detection(flow, flow_tab) {
    var flow_dest_ip = new Netmask(flow["match_tab"]["ipv4_dest"]);
    var flow_source_ip = new Netmask(flow.match_tab.ipv4_source);

    var r = [];
    var Rusult_R = [];
    var shadowing = flow_tab.find((element) => {
        var element_source_ip = new Netmask(element.match_tab.ipv4_source);
        var element_dest_ip = new Netmask(element.match_tab.ipv4_dest);

        if (flow["table_id"] == element["table_id"]) {
            if (flow.id != element.id) {
                if (
                    flow_source_ip.contains(element_source_ip) &&
                    flow_dest_ip.contains(element_dest_ip)
                ) {
                    if (flow.action.value == element.action.value) {
                        r.push({ r1: "redandency ", r2: flow.id, r3: element.id });
                        Rusult_R.push(Conflict_res(flow, element, "redandency"));
                    } else if (element.priority == flow.priority) {
                        r.push({ r1: "correlation  ", r2: flow.id, r3: element.id });

                        // Rusult_R.push(Conflict_res(flow, element, "correlation"));
                    } else if (element.priority < flow.priority) {
                        r.push({ r1: "shadowing_new ", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "shadowing_new"));
                    } else if (element.priority > flow.priority) {
                        r.push({ r1: "generalization_new", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "generalization_new"));
                    } else {
                        console.log("err 0 ");
                    }
                } else if (
                    element_source_ip.contains(flow_source_ip) &&
                    element_dest_ip.contains(flow_dest_ip)
                ) {
                    if (flow.action.value == element.action.value) {
                        r.push({ r1: "redandency ", r2: flow.id, r3: element.id });
                        Rusult_R.push(Conflict_res(flow, element, "redandency"));
                    } else if (element.priority == flow.priority) {
                        r.push({ r1: "correlation", r2: flow.id, r3: element.id });

                        // Rusult_R.push(Conflict_res(flow, element, "correlation"));
                    } else if (flow.priority > element.priority) {
                        r.push({ r1: "generalization_old", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "generalization_old"));
                        // moul priority seghira hewa generalisation ta3  kebira
                    } else if (element.priority > flow.priority) {
                        r.push({ r1: "shadowing_old", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "shadowing_old"));
                    } else {
                        console.log("err 1 ");
                    }
                } else if (
                    (flow_source_ip.contains(element_source_ip) &&
                        element_dest_ip.contains(flow_dest_ip)) ||
                    (element_source_ip.contains(flow_source_ip) &&
                        flow_dest_ip.contains(element_dest_ip))
                ) {
                    if (flow.action.value == element.action.value) {
                        r.push({ r1: "overlap  ", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "overlap"));
                    } else {
                        r.push({ r1: "correlation", r2: flow.id, r3: element.id });

                        Rusult_R.push(Conflict_res(flow, element, "correlation"));
                    }
                } else {
                    console.log("No thing  Match !!!! ");
                }
            } else {}
        }
    });
    return Rusult_R;
}
module.exports = {
    Data_Extraction,
    flow_extraction,
    flows_exctract,
    conflict_detection,
};