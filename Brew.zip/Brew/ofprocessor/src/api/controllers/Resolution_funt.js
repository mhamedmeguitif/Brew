var Netmask = require("netmask").Netmask;
const { AddFlow, DelFlow } = require("./Flow_Manipulation");
const cidrTools = require("cidr-tools");

const AntiIntersection = (New_Rule, Old_Rule) => {
    /**
     * In this case we need to add some priority to the new rule
     */
    New_Rule.priority = New_Rule.priority + 100;
    AddFlow(
        New_Rule,
        New_Rule.match_tab.ipv4_source,
        New_Rule.match_tab.ipv4_dest
    );
    /**
     * if the Priority is the Same yOU Should Make The Res Manually by the Network Admin 
     */
    console.log("This is From Anti-Intersection just a Notification ")
};

const AntiOverlap = (New_Rule, Old_Rule) => {
    var Reslted_Flow = {
        node_id: "openflow:1",
        id: "3",
        action: { name: "output-node-connector", value: "1" },
        match_tab: { ipv4_dest: "10.211.1.0/24", ipv4_source: "10.5.50.5/32" },
        priority: "0",
        table_id: "0",
    };
    Reslted_Flow.id = Old_Rule.id;
    Reslted_Flow.node_id = Old_Rule.node_id;
    Reslted_Flow.match_tab.ipv4_source = Old_Rule.match_tab.ipv4_source;
    Reslted_Flow.match_tab.ipv4_dest = Old_Rule.match_tab.ipv4_dest;
    Reslted_Flow.action.name = Old_Rule.action.name;
    Reslted_Flow.action.value = Old_Rule.action.value;
    Reslted_Flow.priority = Old_Rule.priority;
    Reslted_Flow.table_id = Old_Rule.table_id;

    var Blook___src__1 = new Netmask(New_Rule.match_tab.ipv4_source);
    var Blook___dst__1 = new Netmask(New_Rule.match_tab.ipv4_dest);
    var Blook___src__2 = new Netmask(Old_Rule.match_tab.ipv4_source);
    var Blook___dst__2 = new Netmask(Old_Rule.match_tab.ipv4_dest);
    if (Blook___src__1.contains(Old_Rule.match_tab.ipv4_source)) {
        var new_Source = cidrTools.merge(
            New_Rule.match_tab.ipv4_source,
            Old_Rule.match_tab.ipv4_source
        );
        var new_Dst = cidrTools.merge(
            Old_Rule.match_tab.ipv4_dest,
            New_Rule.match_tab.ipv4_dest
        );
        Reslted_Flow.match_tab.ipv4_source = new_Source[0];

        Reslted_Flow.match_tab.ipv4_dest = new_Dst[0];
    } else {
        var new_Source = cidrTools.merge(
            Old_Rule.match_tab.ipv4_source,
            New_Rule.match_tab.ipv4_source
        );
        var new_Dst = cidrTools.merge(
            New_Rule.match_tab.ipv4_dest,
            Old_Rule.match_tab.ipv4_dest
        );
        Reslted_Flow.match_tab.ipv4_source = new_Source[0];
        //console.log(new_Source)
        Reslted_Flow.match_tab.ipv4_dest = new_Dst[0];
    }
    DelFlow(New_Rule);
    DelFlow(Old_Rule);
    AddFlow(
        Reslted_Flow,
        Reslted_Flow.match_tab.ipv4_source,
        Reslted_Flow.match_tab.ipv4_dest
    );
    console.log("This is From Anti-Overlalp just a Notification ")

    return Reslted_Flow;
};


const AntiGeneralisation = () => {

}



module.exports = { AntiIntersection, AntiOverlap }