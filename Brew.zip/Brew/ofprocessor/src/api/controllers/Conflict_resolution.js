const { AntiIntersection, AntiOverlap } = require("./Resolution_funt");
const { AddFlow, DelFlow } = require("./Flow_Manipulation");
const cidrTools = require("cidr-tools");
var Netmask = require("netmask").Netmask;

const Conflict_res = (newRule, Old_Rule, ConflictType) => {
    var Result = {
        Conflict_Type: "",
        Conflict_Rules: { newRule, Old_Rule, newRuleAdd: {} },
        Resolution_msg: "",
    };
    console.log(ConflictType)
    if (ConflictType.startsWith("shadowing") || ConflictType == "redandency") {
        console.log(ConflictType)
        if (ConflictType.startsWith("shadowing")) {
            if (ConflictType == "shadowing_new") {
                DelFlow(Old_Rule);

                Result.Conflict_Type = ConflictType;
                Result.Conflict_Rules.newRuleAdd = Old_Rule;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg = "Rule " + Old_Rule.id + "has been deleted ";
            } else {
                DelFlow(newRule);
                Result.Conflict_Type = ConflictType;
                Result.Conflict_Rules.newRuleAdd = newRule;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg = "Rule " + newRule.id + "has been deleted ";
            }
        } else {
            var Blook___src1 = new Netmask(newRule.match_tab.ipv4_source);

            var Blook___src2 = new Netmask(Old_Rule.match_tab.ipv4_source);

            if (
                Blook___src1.contains(Old_Rule.match_tab.ipv4_source) &&
                Blook___src2.contains(Old_Rule.match_tab.ipv4_dest)
            ) {
                DelFlow(Old_Rule);
                Result.Conflict_Type = ConflictType;
                Result.Conflict_Rules.newRuleAdd = Old_Rule;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg = "Rule " + Old_Rule.id + "has been deleted ";
            } else {
                DelFlow(newRule);
                Result.Conflict_Type = ConflictType;
                Result.Conflict_Rules.newRuleAdd = newRule;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg = "Rule " + newRule.id + "has been deleted ";
            }
        }
    } else if (ConflictType == "overlap") {
        Result.Conflict_Type = ConflictType;
        Result.Conflict_Rules.newRuleAdd = AntiOverlap(newRule, Old_Rule);
        Result.Conflict_Rules.newRule = newRule;
        Result.Conflict_Rules.Old_Rule = Old_Rule;
        Result.Resolution_msg =
            "Rule " +
            newRule.id +
            " and Rule " +
            Old_Rule.id +
            " Has been  merged to rule " +
            Result.Conflict_Rules.newRuleAdd;
    } else {
        // this mean that we have Corrolation or Generalization
        if (
            ConflictType == "corrolation" &&
            newRule.priority == Old_Rule.priority
        ) {
            AntiIntersection(newRule, Old_Rule);
        } else if (ConflictType.startsWith("generalization")) {
            Result.Conflict_Type = ConflictType;
            if (ConflictType == "generalization_new") {
                Result.Conflict_Rules.newRuleAdd = null;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg =
                    "Rule " + newRule.id + "contains " + Old_Rule.id;
            } else if (ConflictType == "generalization_old") {
                Result.Conflict_Rules.newRuleAdd = null;
                Result.Conflict_Rules.newRule = newRule;
                Result.Conflict_Rules.Old_Rule = Old_Rule;
                Result.Resolution_msg =
                    "Rule " + Old_Rule.id + "contains " + newRule.id;
            } else {}
        } else if (ConflictType == "correlation" &&
            newRule.priority != Old_Rule.priority) {
            Result.Conflict_Type = ConflictType;
            Result.Conflict_Rules.newRuleAdd = null;
            Result.Conflict_Rules.newRule = newRule;
            Result.Conflict_Rules.Old_Rule = Old_Rule;
            Result.Resolution_msg =
                "There is  an intersection in the Adress Spaces between : " +
                newRule.id +
                " and Rule " +
                Old_Rule.id
        } else {

        }
    }
    return Result;
};

module.exports = { Conflict_res };