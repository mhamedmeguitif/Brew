const axios = require("axios");
var uniqid = require("uniqid");
exports.AddFlow = (flow_to_add, new_ipv4_src, new_ipv4_dst) => {
    const baseUrl =
        "http://192.168.0.188:8181/restconf/config/opendaylight-inventory:nodes/node/";
    var fullUrl = baseUrl
        .concat(flow_to_add.node_id)
        .concat("/table/")
        .concat(flow_to_add.table_id)
        .concat("/");
    const config = { auth: { username: "admin", password: "admin" } };
    var Flow = {}
    var Flow_drop = {
        flow: [{
            table_id: 0,
            id: "Id-1",
            cookie: "0",
            priority: 1001,
            "flow-name": "Mhamed1",
            "hard-timeout": 18000,
            "idle-timeout": 18000,
            match: {
                "ethernet-match": {
                    "ethernet-type": {
                        "type": "0x800"
                    }
                },
                "ipv4-source": "10.0.0.1/8",
                "ipv4-destination": "10.0.0.2/8",
            },
            instructions: {
                instruction: [{
                    order: 0,
                    "apply-actions": {
                        action: [{
                            order: 0,
                            "drop-action": {},
                        }, ],
                    },
                }, ],
            },
        }, ],
    };
    var Flow_forward = {
        flow: [{
            table_id: 0,
            id: "Id-1",
            cookie: "0",
            priority: 1001,

            "hard-timeout": 3600,
            "idle-timeout": 1800,
            match: {
                "ethernet-match": {
                    "ethernet-type": {
                        "type": "0x800"
                    }
                },
                "ipv4-source": "10.0.0.1/8",
                "ipv4-destination": "10.0.0.2/8",
            },
            instructions: {
                instruction: [{
                    order: 0,
                    "apply-actions": {
                        action: [{
                            order: 0,
                            "output-action": {
                                "output-node-connector": "3",
                                "max-length": "65535"
                            },
                        }, ],
                    },
                }, ],
            },
        }, ],
    };
    if (flow_to_add.action.name == 'drop-action') {
        Flow = Flow_drop
    } else {
        Flow = Flow_forward

        Flow.flow[0].instructions.instruction[0]['apply-actions'].action[0]['output-action']['output-node-connector'] = flow_to_add.action.value

    }

    Flow.flow[0]["id"] = uniqid();
    Flow.flow[0]["match"]["ipv4-source"] = new_ipv4_src;
    Flow.flow[0]["match"]["ipv4-destination"] = new_ipv4_dst;
    Flow.flow[0]["priority"] = flow_to_add.priority;
    axios
        .post(fullUrl, Flow, config)
        .then((res) => {
            console.log(res.status);
        })
        .catch((err) => {
            console.log(err);
        });


};

exports.DelFlow = (Flow_to_del) => {
    const baseUrl =
        "http://192.168.0.188:8181/restconf/config/opendaylight-inventory:nodes/node/";
    const fullUrl = baseUrl
        .concat(Flow_to_del.node_id)
        .concat("/table/")
        .concat(Flow_to_del.table_id)
        .concat("/flow/")
        .concat(Flow_to_del.id);
    const config = { auth: { username: "admin", password: "admin" } };
    axios
        .delete(fullUrl, config)
        .then((res) => {
            console.log(res.status);
        })
        .catch((err) => {
            console.log(err);
        });
    console.log(fullUrl);
};