const db = require("../Models");
const Node = db.node;
var deepEqual = require("deep-equal");

exports.saveNode = (req, res) => {
    const Node1 = new Node();
    var topo = [];

    Node.find()
        .then((result) => {
            // console.log("-----------the new topo-------------");
            var topo_new = req.body.nodes.node;
            // console.log(topo_new);
            // console.log("-------------the Old topo---------");
            //console.log(result[0].node);
            // test of the length of the resulted data

            console.log(
                "-----------test if the tow tables have the same nodes number-------- "
            );
            const newTopo_Lenght = topo_new.length;
            const OldTopo_Lenght = result[0].node.length;
            //console.log("new topo " + newTopo_Lenght);
            //console.log("old topo " + OldTopo_Lenght);
            var IsLengthSame = newTopo_Lenght == OldTopo_Lenght;
            if (IsLengthSame) {
                // console.log(
                //     "The Two tables have The Same NUmber of OVS : " + IsLengthSame
                // );
                // check  for the   First Node if is the same (Node_Name  check  )
                //console.log("---------first loop---------");
                var isNodeSame = true;
                var isFlowTableNbrSame = true;
                var FlowSame = true;
                for (let j = 0; j < result[0].node.length; j++) {
                    console.log("--------- loop for the node list --" + (j + 1) + " ----------");
                    for (let i = 0; i < topo_new.length; i++) {

                        /** 
                         *
                         *  Compare the Same Node !!!!!!!!!!!!!!!!!! 
                         * 
                         * */

                        if (topo_new[i].id == result[0].node[j].id) {
                            /**
                             * 
                             * check if the number of Flow Tables is equal :
                             *
                             */
                            if (
                                topo_new[i]["flow-node-inventory:table"].length ==
                                result[0].node[j]["flow-node-inventory:table"].length
                            ) {
                                //  console.log(
                                //        "The number of flow table  for the old one : " +
                                //        result[0].node[j]["flow-node-inventory:table"].length +
                                //       " For the new one : " +
                                //       topo_new[i]["flow-node-inventory:table"].length
                                //   );
                                isFlowTableNbrSame = true;
                                /**
                                 * this for access each flow table in the Flow table 
                                 */

                                var isFlowIdExist = false
                                for (
                                    let k = 0; k < topo_new[i]["flow-node-inventory:table"].length; k++
                                ) {

                                    for (
                                        let e = 0; e < result[0].node[j]["flow-node-inventory:table"].length; e++
                                    ) {

                                        //test if the flow table id is the same
                                        if (
                                            result[0].node[j]["flow-node-inventory:table"][e].id ==
                                            topo_new[i]["flow-node-inventory:table"][k].id
                                        ) {
                                            isFlowIdExist = true;

                                            if (topo_new[i]["flow-node-inventory:table"][k].flow && result[0].node[j]["flow-node-inventory:table"][e].flow.length != 0) {




                                                if (topo_new[i]["flow-node-inventory:table"][k].flow.length == result[0].node[j]["flow-node-inventory:table"][e].flow.length) {
                                                    for (let index = 0; index < topo_new[i]["flow-node-inventory:table"][k].flow.length; index++) {

                                                    }

                                                }









                                            } else {
                                                if (!topo_new[i]["flow-node-inventory:table"][k].flow && result[0].node[j]["flow-node-inventory:table"][e].flow.length == 0) {
                                                    console.log("This is prented because the flow table does not esist in the req with ID : " + result[0].node[j]["flow-node-inventory:table"][e].id)
                                                }

                                                /**
                                                 * This bloc handel the case if the flow table is note eaqual 
                                                 */
                                            }

                                        } else {
                                            console.log("Flow Table With Id : " + topo_new[i]["flow-node-inventory:table"][k].id + " Does not exist ")

                                        }




                                    }
                                    console.log("----------------Iteration For Table of Flow Tables  -----" + k)
                                    if (isFlowIdExist == false) {
                                        console.log("Flow Table With Id : " + topo_new[i]["flow-node-inventory:table"][k].id + " Does not exist ")
                                    } else {}
                                }
                                // end test 
                            } else {
                                isFlowTableNbrSame = false;
                                console.log("the lenth is not equal for the flow table of node : " + topo_new[i].id + " make a topology update ")
                                break;
                            }
                            isNodeSame = true;
                        } else {
                            isNodeSame = false;
                        }
                    }
                }
                console.log("The Node Number is equal : " + isNodeSame);
                console.log(
                    "The flow table in each node is equal : " + isFlowTableNbrSame
                );
            } else {
                console.log("The Topology had changed !!!")
            }
        })
        .catch((err) => {
            console.log(err);
        });

    //for (let i = 0; i < req.body.nodes.node.length; i++) {
    //   Node1.node.push(req.body.nodes.node[i]);
    // }

    //console.log(Node1.node[0].id == Node1.node[1].id);

    /* Node1.save((err, node) => {
        if (err) {
            res.status(500).send(node);
            return;
        }
        res.send(node);
    });
 */

    res.send("done");
};