var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var NodeSchema = mongoose.model(
    'Nodes', new Schema({
        node: [{
            id: {
                type: String
            },
            'flow-node-inventory:table': [{

                id: {
                    type: String
                },
                flow: []
            }]
        }]
    })
)

module.exports = NodeSchema;