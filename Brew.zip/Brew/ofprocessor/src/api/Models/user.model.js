const mongoose = require("mongoose");
const User = mongoose.model(
    "User",
    new mongoose.Schema({
        fullName: {
            type: String,
            required: true,
        },
        username: {
            type: String,
            required: true,
        },
        email: {
            type: String,
            required: true,
        },
        password: {
            type: String,
            required: true,
        },
        date: {
            type: Date,
            default: Date.now,
        },
        roles: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: "Role",
            default: "user"
        }, ],
    })
);
module.exports = User;