const express = require("express");
const {
    Data_Extraction,
    flow_extraction,
    flows_exctract,
    conflict_detection,
} = require("../controllers/Conflict_Detection");

const router = express.Router();

router.post("/", (req, res) => {
    if (req.body.children[1].children[3].children[1].value == "deleted") {
        res.send("Done");
    } else {
        var data = Data_Extraction(req.body);
        var flow = flow_extraction(data.Flow, data);
        var flow_tab = flows_exctract(data.FlowTable, data);
        var result = conflict_detection(flow, flow_tab);
        //console.log(result);
        var RES_Res = {
            result: {},
            time: ""
        }
        RES_Res.time = req.body.children[0].value
        RES_Res.result = result
            //console.log(req.body.children[0].value)
        res.send(RES_Res);
    }
});

module.exports = router;