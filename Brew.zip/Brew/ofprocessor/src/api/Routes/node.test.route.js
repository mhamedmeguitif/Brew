const express = require('express');
const controller = require("../controllers/node.test.controller");

const router = express.Router();


router.use(function(req, res, next) {
    res.header(
        "Access-Control-Allow-Headers",
        "Origin, Content-Type, Accept"
    );
    next();
});

router.post('/data', controller.saveNode)


module.exports = router