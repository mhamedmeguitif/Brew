const authJwt = require("./authJWT");
const verifySignUp = require("./verifySignup");
module.exports = {
    authJwt,
    verifySignUp
};